-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mer. 10 mai 2023 à 03:16
-- Version du serveur : 10.4.24-MariaDB
-- Version de PHP : 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `streamtopia`
--

-- --------------------------------------------------------

--
-- Structure de la table `abonnement`
--

CREATE TABLE `abonnement` (
  `User_id` int(11) NOT NULL,
  `id_abon` int(11) NOT NULL,
  `vod` int(11) NOT NULL,
  `audio_books` int(11) NOT NULL,
  `iptv` int(11) NOT NULL,
  `date_deb` date NOT NULL,
  `date_fin` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `abonnement`
--

INSERT INTO `abonnement` (`User_id`, `id_abon`, `vod`, `audio_books`, `iptv`, `date_deb`, `date_fin`) VALUES
(71, 876, 0, 1, 0, '2023-05-12', '2023-05-31'),
(72, 6756, 1, 1, 1, '2023-05-12', '2023-05-31'),
(73, 6757, 0, 0, 1, '2023-05-12', '2023-05-31');

-- --------------------------------------------------------

--
-- Structure de la table `accounts`
--

CREATE TABLE `accounts` (
  `Name` varchar(30) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `User_id` int(11) NOT NULL,
  `Email` varchar(60) NOT NULL,
  `age` int(99) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `accounts`
--

INSERT INTO `accounts` (`Name`, `Password`, `User_id`, `Email`, `age`) VALUES
('pablo', 'lotfi', 71, 'bensalemamine60@gmail.com', 3333),
('ghof', 'ghof', 72, 'ghofghof@gmail.com', 77),
('assil', 'assil', 73, 'assil@gmail.com', 39),
('mahmoud', '5644', 5555, 'mahmoud@gmail.com', 80);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `abonnement`
--
ALTER TABLE `abonnement`
  ADD PRIMARY KEY (`id_abon`),
  ADD KEY `jointure` (`User_id`);

--
-- Index pour la table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`User_id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `abonnement`
--
ALTER TABLE `abonnement`
  MODIFY `id_abon` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6758;

--
-- AUTO_INCREMENT pour la table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `User_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5556;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `abonnement`
--
ALTER TABLE `abonnement`
  ADD CONSTRAINT `abonnement_ibfk_1` FOREIGN KEY (`User_id`) REFERENCES `accounts` (`User_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `jointure` FOREIGN KEY (`User_id`) REFERENCES `accounts` (`User_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
